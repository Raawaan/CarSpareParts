package com.example.carspareparts

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
//import com.parse.ParseInstallation

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
//        ParseInstallation.getCurrentInstallation().saveInBackground()

    }
}
